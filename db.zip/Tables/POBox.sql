CREATE TABLE [dbo].[POBox] (
    [BoxId]           INT            IDENTITY (1, 1) NOT NULL,
    [BoxName]         NVARCHAR (200) NOT NULL,
    [ManagerId]       INT            NOT NULL,
    [EmployeeId]      INT            NOT NULL,
    [LocationId]      INT            NOT NULL,
    [DeviceId]        INT            NULL,
    [Status]          NVARCHAR (20)  NOT NULL,
    [StartDate]       DATETIME       DEFAULT (getdate()) NOT NULL,
    [EndDate]         DATETIME       NULL,
    [IsDeleted]       BIT            DEFAULT ((0)) NOT NULL,
    [PurchaseOrderNo] NVARCHAR (100) NULL,
    [IsMerged]        BIT            CONSTRAINT [DEFAULT_POBox_IsMerged] DEFAULT ((0)) NOT NULL,
    PRIMARY KEY CLUSTERED ([BoxId] ASC),
    CHECK ([Status]='Posted' OR [Status]='Unposted'),
    FOREIGN KEY ([DeviceId]) REFERENCES [dbo].[Device] ([DeviceId]),
    FOREIGN KEY ([EmployeeId]) REFERENCES [dbo].[User] ([UserId]),
    FOREIGN KEY ([LocationId]) REFERENCES [dbo].[Location] ([LocationId]),
    FOREIGN KEY ([ManagerId]) REFERENCES [dbo].[User] ([UserId])
);


GO

