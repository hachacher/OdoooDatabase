CREATE TABLE [dbo].[ImportedPurchaseOrders] (
    [Id]               INT             IDENTITY (1, 1) NOT NULL,
    [PurchaseOrderNo]  NVARCHAR (100)  NULL,
    [ProductId]        NVARCHAR (150)  NULL,
    [ProductVariantId] NVARCHAR (150)  NULL,
    [ItemNo]           NVARCHAR (100)  NULL,
    [VariantCode]      NVARCHAR (100)  NULL,
    [Quantity]         DECIMAL (18, 2) NULL,
    [BoxNo]            NVARCHAR (50)   NULL,
    [LocationId]       INT             NULL,
    [Barcode]          NVARCHAR (100)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ImportedPurchaseOrders_Location] FOREIGN KEY ([LocationId]) REFERENCES [dbo].[Location] ([LocationId])
);


GO

CREATE NONCLUSTERED INDEX [IX_ImportedPurchaseOrders_LocationId]
    ON [dbo].[ImportedPurchaseOrders]([LocationId] ASC);


GO

